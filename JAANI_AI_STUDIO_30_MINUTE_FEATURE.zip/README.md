# JAANI AI STUDIO

Android starter project for the JAANI AI STUDIO creator app.

## New: Long-form AI Movie Maker (up to 30 minutes)
The Create tab now includes a long-form project brief screen with:
- Script input and selectable durations from 5 to 30 minutes.
- 9:16 and 16:9 output formats.
- Toggles for AI visuals, character voiceover, music/SFX, subtitles, and automatic editing.
- A clearly stated owner-only credit benefit policy.

This is currently the Android UI/project-brief stage. It does **not** generate a finished video yet. Real generation requires a secure backend, AI video/image and voice providers, storage, a render/assembly worker, and job status/resume support.

## Owner-only credit policy (must be enforced server-side)
- Store the owner's immutable account UID in a private server environment variable or admin configuration; never hard-code it in the Android app.
- For every generation request, the backend authenticates the session and compares the verified UID with the configured owner UID.
- Only that UID receives the special allowance sufficient for projects up to 30 minutes. All other accounts use normal credit rules.
- Calculate and reserve credits on the server before starting work; settle/refund based on completed work and failures.
- Never accept `isOwner`, credit balance, or duration entitlement sent by the client as authoritative.
- Keep provider API keys on the server, not in the APK.

## Long-form generation architecture (next implementation phase)
1. Authenticate user and validate script/duration (maximum 30 minutes).
2. Split script into timed scenes and persist a project manifest.
3. Generate scene visuals and consistent character references.
4. Generate narration/character audio and align subtitles/lip-sync where supported.
5. Generate or select licensed music/SFX.
6. Render scenes in resumable background jobs, then concatenate/mix and export MP4.
7. Expose progress, retry, cancel, and resume endpoints to the Android app.

## Existing screens
Home, Create, Image, Voice, YouTube, and Account. Account and provider integrations remain UI previews until configured.

## Build
Run `gradle assembleDebug` from the project root, or use the GitHub Actions workflow.
