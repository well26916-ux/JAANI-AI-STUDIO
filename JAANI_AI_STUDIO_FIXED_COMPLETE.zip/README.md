# JAANI AI STUDIO — Android source

A Kotlin + Jetpack Compose Android starter for the JAANI AI STUDIO app.

## Build

The GitHub Actions workflow is `.github/workflows/build.yml`. It builds with JDK 17, Gradle 8.9, Android SDK 35, verifies that the APK exists, and uploads `app-debug.apk` as a downloadable Actions artifact.

Run it from **GitHub → Actions → JAANI AI STUDIO Android APK → Run workflow**. A successful run is required before calling the APK build verified.

## Current implementation status

Implemented in this source package:
- Dark red/black Compose app shell and bottom navigation.
- Home dashboard and feature entry points.
- Image prompt/settings brief screen.
- 5–30 minute movie project brief screen with aspect ratio and production options.
- Voiceover planning screen.
- YouTube SEO planning screen.
- Account form UI with password masking and basic local validation.

Not implemented or connected yet:
- Actual AI image/video/audio generation or lip-sync.
- Server-side long-running job queue, progress, retry, cancellation, storage and MP4 rendering.
- Firebase Authentication, cloud profiles, password reset and database.
- YouTube OAuth/publishing integration.
- Payments/credit ledger and owner entitlement.

The current Create, Image, Voice and YouTube screens prepare local briefs only. They do not claim to generate media.

## Security requirements for the production backend

- Never put provider API keys, Firebase Admin credentials, or privileged secrets in the Android app.
- Verify Firebase ID tokens on the backend for every protected request.
- Determine the owner account from a server-side immutable UID/role allowlist. Never trust a client-supplied `isOwner`, email-only match, or local preference.
- Apply owner-only 30-minute allowance and credit rules on the server for every job; regular users must retain normal limits.
- Store scripts and generated assets with per-user authorization. Use signed, short-lived upload/download URLs where appropriate.
- Process long videos as resumable scene-level jobs with persisted state, bounded retries, cancellation, and server-side final MP4 assembly.

## Important

This is a buildable Android UI/source baseline, not a finished AI generation service. Real AI generation requires selecting providers and deploying a secure backend. No credentials are included in this repository.
