package com.jaani.aistudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF101014)
private val Panel = Color(0xFF1C1C24)
private val Accent = Color(0xFFE53945)
private val Muted = Color(0xFFB8B8C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JaaniStudioApp() }
    }
}

@Composable
fun JaaniStudioApp() {
    var selected by remember { mutableStateOf("Home") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Background,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Home", "Image", "Create", "Voice", "YouTube", "Account").forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Create" -> Icons.Default.Movie
                                        "Image" -> Icons.Default.Image
                                        "Voice" -> Icons.Default.RecordVoiceOver
                                        "YouTube" -> Icons.Default.SmartDisplay
                                        "Account" -> Icons.Default.AccountCircle
                                        else -> Icons.Default.Home
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Accent,
                                selectedTextColor = Accent,
                                indicatorColor = Accent.copy(alpha = 0.15f),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("JAANI AI STUDIO", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("Your AI video creation workspace", color = Muted, fontSize = 13.sp)
                }
                item {
                    when (selected) {
                        "Create" -> CreateScreen()
                        "Image" -> ImageScreen()
                        "Voice" -> VoiceScreen()
                        "YouTube" -> YouTubeScreen()
                        "Account" -> AccountScreen()
                        else -> HomeScreen(onOpen = { selected = it })
                    }
                }
                item {
                    Text(
                        "Starter build • API connections are added securely in the next phase",
                        color = Muted, fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Accent), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Create your next video", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Plan, generate, edit and prepare YouTube content in one place.", color = Color.White)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { onOpen("Create") }, colors = ButtonDefaults.buttonColors(containerColor = Color.White)) {
                    Text("Start creating", color = Accent)
                }
            }
        }
        FeatureCard("AI Image Studio", "Prepare image prompts and choose styles and aspect ratios", Icons.Default.Image) { onOpen("Image") }
        FeatureCard("30-Minute AI Movie Maker", "Turn a full script into scenes, voiceover, music and an edited video", Icons.Default.Movie) { onOpen("Create") }
        FeatureCard("Voiceover Studio", "Prepare narration, voice and subtitles", Icons.Default.RecordVoiceOver) { onOpen("Voice") }
        FeatureCard("YouTube SEO Studio", "Generate titles, description, tags and more", Icons.Default.SmartDisplay) { onOpen("YouTube") }
        FeatureCard("Video Editor", "Trim, arrange clips and prepare export settings", Icons.Default.Edit) { onOpen("Create") }
    }
}

@Composable
fun FeatureCard(title: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, color = Color.White)
                Text(detail, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
fun CreateScreen() {
    var script by remember { mutableStateOf("") }
    var ratio by remember { mutableStateOf("16:9 YouTube") }
    var duration by remember { mutableStateOf(30) }
    var voiceover by remember { mutableStateOf(true) }
    var visuals by remember { mutableStateOf(true) }
    var music by remember { mutableStateOf(true) }
    var subtitles by remember { mutableStateOf(true) }
    var autoEdit by remember { mutableStateOf(true) }
    var result by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("LONG-FORM AI MOVIE MAKER", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("Paste a complete script and plan an automatically assembled video up to 30 minutes.", color = Muted)
        OutlinedTextField(
            value = script, onValueChange = { script = it },
            label = { Text("Paste your complete video script") },
            modifier = Modifier.fillMaxWidth(), minLines = 7
        )
        Text("Maximum duration: 30 minutes", color = Accent, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(5, 10, 15).forEach { mins ->
                FilterChip(selected = duration == mins, onClick = { duration = mins }, label = { Text("${mins}m") })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(20, 25, 30).forEach { mins ->
                FilterChip(selected = duration == mins, onClick = { duration = mins }, label = { Text("${mins}m") })
            }
        }
        Text("Output format", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("9:16 Shorts", "16:9 YouTube").forEach {
                FilterChip(selected = ratio == it, onClick = { ratio = it }, label = { Text(it) })
            }
        }
        Text("Automatic production steps", color = Muted, fontWeight = FontWeight.SemiBold)
        ProductionToggle("AI scene visuals", visuals) { visuals = it }
        ProductionToggle("Character voiceover and narration", voiceover) { voiceover = it }
        ProductionToggle("Background music and sound effects", music) { music = it }
        ProductionToggle("Subtitles and captions", subtitles) { subtitles = it }
        ProductionToggle("Automatic scene editing and transitions", autoEdit) { autoEdit = it }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("JAANI OWNER CREDIT BENEFIT", color = Accent, fontWeight = FontWeight.Bold)
                Text("The special allowance for videos up to 30 minutes is reserved for the verified owner account. Other accounts keep their normal credit limits.", color = Color.White, fontSize = 13.sp)
                Text("Security rule: owner status and credits must be checked by the backend for every generation job; never trust a value stored only on this phone.", color = Muted, fontSize = 11.sp)
            }
        }
        Button(onClick = {
            result = when {
                script.isBlank() -> "Please paste your script first."
                !voiceover && !visuals -> "Select at least voiceover or AI visuals for the production."
                else -> "LONG-FORM PROJECT BRIEF READY\nDuration: $duration minutes\nFormat: $ratio\nScript length: ${script.length} characters\n\nEnabled: ${listOfNotNull(if (visuals) "AI visuals" else null, if (voiceover) "voiceover" else null, if (music) "music/SFX" else null, if (subtitles) "subtitles" else null, if (autoEdit) "automatic editing" else null).joinToString()}\n\nThis is a saved project brief only. Real generation, rendering, and owner-credit enforcement require the secure backend and AI provider connections."
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Prepare ${duration}-minute video project") }
        if (result.isNotBlank()) Text(result, color = Color.White, modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp))
        Text("Long videos will be processed as resumable scene-by-scene jobs on a server, then assembled and exported as MP4. This Android screen is the first UI step; generation is not connected yet.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun ProductionToggle(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange, colors = CheckboxDefaults.colors(checkedColor = Accent))
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
fun VoiceScreen() {
    var script by remember { mutableStateOf("") }
    var language by remember { mutableStateOf("Urdu") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("VOICEOVER STUDIO", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        OutlinedTextField(script, { script = it }, label = { Text("Paste narration script") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
        Text("Language", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Urdu", "English", "Hindi").forEach {
                FilterChip(selected = language == it, onClick = { language = it }, label = { Text(it) })
            }
        }
        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Generate voiceover") }
        Text("Voice provider and audio export will be connected in Phase 2.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun YouTubeScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("YOUTUBE SEO STUDIO", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("The nine optimization tools planned for your videos:", color = Muted)
        val tools = listOf(
            "1. Viral-style title ideas",
            "2. SEO description",
            "3. Relevant hashtags",
            "4. Search keywords and tags",
            "5. Suggested video category",
            "6. Audience setting guidance",
            "7. Thumbnail text ideas",
            "8. Pinned comment",
            "9. SEO and publishing strategy"
        )
        tools.forEach { Text(it, color = Color.White, modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).padding(12.dp)) }
        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Generate YouTube package") }
        OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Connect YouTube channel (OAuth in Phase 3)") }
        Text("The app will never ask you to share your Google password. Channel access will use Google's official permission screen.", color = Muted, fontSize = 12.sp)
    }
}


@Composable
fun AccountScreen() {
    var isSignup by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("JAANI ACCOUNT", fontWeight = FontWeight.Black, fontSize = 21.sp)
        Text(if (isSignup) "Create your studio profile" else "Welcome back to your studio", color = Muted)
        if (isSignup) OutlinedTextField(name, { name = it }, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(email, { email = it }, label = { Text("Email address") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password (minimum 8 characters)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
        )
        Button(onClick = {
            message = when {
                isSignup && name.isBlank() -> "Please enter your name."
                !android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() -> "Please enter a valid email address."
                password.length < 8 -> "Password must contain at least 8 characters."
                else -> "Form validated. Secure account service is not connected yet; no account was created."
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (isSignup) "Create account" else "Sign in") }
        TextButton(onClick = { isSignup = !isSignup; message = "" }) {
            Text(if (isSignup) "Already have an account? Sign in" else "New here? Create an account", color = Accent)
        }
        if (message.isNotBlank()) Text(message, color = if (message.startsWith("Form")) Accent else Muted, fontSize = 13.sp)
        Text("Demo screen only: authentication is not connected yet. Do not enter a real password until Firebase Authentication is configured.", color = Muted, fontSize = 12.sp)
    }
}


@Composable
fun ImageScreen() {
    var prompt by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("Cinematic 3D") }
    var ratio by remember { mutableStateOf("9:16 Portrait") }
    var result by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("AI IMAGE STUDIO", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("Prepare a detailed image-generation brief", color = Muted)
        OutlinedTextField(
            value = prompt, onValueChange = { prompt = it },
            label = { Text("Describe the image you want") },
            modifier = Modifier.fillMaxWidth(), minLines = 4
        )
        Text("Visual style", color = Muted)
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Cinematic 3D", "Ghibli-inspired", "Photorealistic", "Anime", "Surreal CGI").forEach { item ->
                FilterChip(selected = style == item, onClick = { style = item }, label = { Text(item) })
            }
        }
        Text("Aspect ratio", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("9:16 Portrait", "1:1 Square", "16:9 Landscape").forEach { item ->
                FilterChip(selected = ratio == item, onClick = { ratio = item }, label = { Text(item) })
            }
        }
        Button(onClick = {
            result = if (prompt.isBlank()) "Please describe your image first."
            else "Image brief ready\n\nPrompt: $prompt\nStyle: $style\nAspect ratio: $ratio\n\nImage-generation API is not connected yet, so no image has been generated."
        }, modifier = Modifier.fillMaxWidth()) { Text("Prepare image brief") }
        if (result.isNotBlank()) {
            Text(result, color = Color.White, modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp))
        }
        Text("This feature prepares your image settings. Connect an image-generation provider to generate and download actual images.", color = Muted, fontSize = 12.sp)
    }
}
