# JAANI AI STUDIO — Android starter

This is the first Android UI starter for the creator app.

## Current starter screens
- Home dashboard
- AI video project settings (prompt, aspect ratio, duration)
- Voiceover script and language screen
- YouTube SEO checklist with all nine planned tools

## Important
This is a UI starter, not a finished AI generator. Video generation, voice synthesis, editing/export, AI SEO generation and YouTube publishing require secure backend services and provider integrations. No API keys or Google passwords should be placed in the Android app source.

## Build
Open this folder as an Android project in Android Studio, or use the included GitHub Actions workflow to build a debug APK.

Package: `com.jaani.aistudio`
Min Android: 8.0 (API 26)
