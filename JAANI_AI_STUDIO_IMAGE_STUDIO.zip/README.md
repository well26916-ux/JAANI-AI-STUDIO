# JAANI AI STUDIO

Android starter project with Home, Create, Voice, YouTube and Account screens.

## Account feature status
The Account tab now includes sign-in and sign-up forms with basic input validation. This is a UI preview only. It does not create accounts or authenticate users. Firebase Authentication and a project-specific `google-services.json` must be configured before real authentication can be enabled. Do not enter real passwords in this preview.

## Build
Run `gradle assembleDebug` from the project root, or use the repository GitHub Actions workflow.

## Current integration status
AI image/video generation, voice synthesis, video rendering/export, YouTube OAuth/publishing, and cloud authentication require provider/backend setup and are not yet connected.
