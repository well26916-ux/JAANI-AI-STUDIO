# JAANI AI STUDIO — checked source package

Android project package for the current UI prototype.

## Included screens
- Home dashboard
- AI Image Studio prompt/style/aspect-ratio brief
- Long-form video project brief with 5–30 minute duration options
- Voiceover Studio UI
- YouTube SEO checklist (9 planned tools)
- Account sign-in/sign-up form validation UI
- GitHub Actions workflow to build and upload a debug APK

## Important implementation status
This is **not yet a fully connected AI video-generation app**. The current screens prepare project briefs and validate forms. The following remain pending:
1. Firebase Authentication and verified owner-account role.
2. Secure backend and server-side credit ledger/owner-only 30-minute allowance.
3. AI image/video generation provider integration.
4. Text-to-speech/voice provider integration.
5. Long-running scene queue, media storage, video assembly/rendering and MP4 export.
6. Working YouTube OAuth connection and publishing integration.
7. Real functional implementations for the nine YouTube SEO tools.

Do not enter a real password in the demo account screen until authentication is connected.

## Build
The repository-root workflow at `.github/workflows/build.yml` builds the Android debug APK on GitHub Actions. Upload this package's **contents** to the repository root (so `.github` and `app` are at the root), then run **Actions → JAANI AI STUDIO Android APK → Run workflow**. The APK is uploaded as a workflow artifact.

## Project configuration
- Package: `com.jaani.aistudio`
- Minimum Android: API 26 (Android 8.0)
- Compile/target SDK: 35
- JDK: 17
- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21
- Gradle workflow: 8.9
