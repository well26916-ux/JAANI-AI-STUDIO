# JAANI AI STUDIO — Android UI prototype

Android app prototype for the JAANI AI STUDIO creator workflow.

## Included screens
- Home dashboard
- AI video project settings (prompt, aspect ratio, duration)
- Voiceover script and language screen
- YouTube SEO tools checklist

## Important status
This is a buildable UI prototype, not a complete AI production service. The video and voice buttons are placeholders. Real video generation, voice synthesis, editing/export, AI-generated SEO, and YouTube channel upload still need provider/backend integrations. This ZIP does not claim those services are operational.

## Build
The GitHub Actions workflow at `.github/workflows/android.yml` builds a debug APK when run manually or when code is pushed to `main`. The project uses JDK 17 and Gradle 8.9.

Package: `com.jaani.aistudio`
Minimum Android: 8.0 (API 26)
