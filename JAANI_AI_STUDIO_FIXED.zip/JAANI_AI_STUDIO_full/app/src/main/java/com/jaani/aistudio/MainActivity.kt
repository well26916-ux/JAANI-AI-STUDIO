package com.jaani.aistudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF101014)
private val Panel = Color(0xFF1C1C24)
private val Accent = Color(0xFFE53945)
private val Muted = Color(0xFFB8B8C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JaaniStudioApp() }
    }
}

@Composable
fun JaaniStudioApp() {
    var selected by remember { mutableStateOf("Home") }
    var showInfo by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Background,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Home", "Create", "Voice", "YouTube").forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Create" -> Icons.Default.Movie
                                        "Voice" -> Icons.Default.RecordVoiceOver
                                        "YouTube" -> Icons.Default.YouTube
                                        else -> Icons.Default.Home
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Accent,
                                selectedTextColor = Accent,
                                indicatorColor = Accent.copy(alpha = 0.15f),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("JAANI AI STUDIO", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("Your AI video creation workspace", color = Muted, fontSize = 13.sp)
                }
                item {
                    when (selected) {
                        "Create" -> CreateScreen()
                        "Voice" -> VoiceScreen()
                        "YouTube" -> YouTubeScreen()
                        else -> HomeScreen(onOpen = { selected = it })
                    }
                }
                item {
                    Text(
                        "Starter build • API connections are added securely in the next phase",
                        color = Muted, fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Accent), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Create your next video", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Plan, generate, edit and prepare YouTube content in one place.", color = Color.White)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { onOpen("Create") }, colors = ButtonDefaults.buttonColors(containerColor = Color.White)) {
                    Text("Start creating", color = Accent)
                }
            }
        }
        FeatureCard("AI Video Generator", "Turn a story or prompt into a video project", Icons.Default.Movie) { onOpen("Create") }
        FeatureCard("Voiceover Studio", "Prepare narration, voice and subtitles", Icons.Default.RecordVoiceOver) { onOpen("Voice") }
        FeatureCard("YouTube SEO Studio", "Generate titles, description, tags and more", Icons.Default.YouTube) { onOpen("YouTube") }
        FeatureCard("Video Editor", "Trim, arrange clips and prepare export settings", Icons.Default.Edit) { onOpen("Create") }
    }
}

@Composable
fun FeatureCard(title: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, color = Color.White)
                Text(detail, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
fun CreateScreen() {
    var prompt by remember { mutableStateOf("") }
    var ratio by remember { mutableStateOf("9:16 Shorts") }
    var duration by remember { mutableStateOf("30 seconds") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("AI VIDEO GENERATOR", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        OutlinedTextField(
            value = prompt, onValueChange = { prompt = it },
            label = { Text("Describe your video idea") },
            modifier = Modifier.fillMaxWidth(), minLines = 4
        )
        Text("Video format", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("9:16 Shorts", "16:9 YouTube").forEach {
                FilterChip(selected = ratio == it, onClick = { ratio = it }, label = { Text(it) })
            }
        }
        Text("Duration", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("15 seconds", "30 seconds", "60 seconds").forEach {
                FilterChip(selected = duration == it, onClick = { duration = it }, label = { Text(it) })
            }
        }
        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Create video project") }
        Text("Generation provider connection will be added in Phase 2. This button is currently a UI placeholder.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun VoiceScreen() {
    var script by remember { mutableStateOf("") }
    var language by remember { mutableStateOf("Urdu") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("VOICEOVER STUDIO", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        OutlinedTextField(script, { script = it }, label = { Text("Paste narration script") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
        Text("Language", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Urdu", "English", "Hindi").forEach {
                FilterChip(selected = language == it, onClick = { language = it }, label = { Text(it) })
            }
        }
        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Generate voiceover") }
        Text("Voice provider and audio export will be connected in Phase 2.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun YouTubeScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("YOUTUBE SEO STUDIO", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("The nine optimization tools planned for your videos:", color = Muted)
        val tools = listOf(
            "1. Viral-style title ideas",
            "2. SEO description",
            "3. Relevant hashtags",
            "4. Search keywords and tags",
            "5. Suggested video category",
            "6. Audience setting guidance",
            "7. Thumbnail text ideas",
            "8. Pinned comment",
            "9. SEO and publishing strategy"
        )
        tools.forEach { Text(it, color = Color.White, modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).padding(12.dp)) }
        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Generate YouTube package") }
        OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Connect YouTube channel (OAuth in Phase 3)") }
        Text("The app will never ask you to share your Google password. Channel access will use Google's official permission screen.", color = Muted, fontSize = 12.sp)
    }
}
