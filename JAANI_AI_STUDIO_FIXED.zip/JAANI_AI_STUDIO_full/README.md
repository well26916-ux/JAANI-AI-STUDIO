# JAANI AI STUDIO — Android starter

This is the Android UI starter for the JAANI AI STUDIO creator app.

## Included screens
- Home dashboard
- AI video project settings (prompt, aspect ratio, duration)
- Voiceover script and language screen
- YouTube SEO checklist with nine planned tools

## Current status
This is a UI starter, not a finished AI generator. The current buttons are UI placeholders. Real video generation, voice synthesis, video editing/export, AI SEO generation, and YouTube publishing still require backend services and provider integrations.

## Build configuration
- Package: `com.jaani.aistudio`
- Minimum Android: 8.0 (API 26)
- Compile/target SDK: 35
- Java and Kotlin JVM targets: 17

The Java/Kotlin JVM target mismatch from the previous build log has been addressed by setting both targets to 17. A fresh GitHub Actions run is still required to confirm the APK builds successfully.

Do not put API keys, OAuth client secrets, or Google passwords in the Android source code.
